from django.shortcuts import render
from .models import Blog 
# Create your views here.
def blogs(request):
	blog = Blog.objects
	return render(request,'blogs.html' , {'all_blogs':blog})